package com.example.storygo.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.storygo.injection.Data
import com.example.storygo.repository.UserRepo

class FactoryVM (
    private val repository: UserRepo
) : ViewModelProvider.NewInstanceFactory(){

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(RegisterVM::class.java) -> {
                RegisterVM(repository) as T
            }
            modelClass.isAssignableFrom(LoginVM::class.java) -> {
                LoginVM(repository) as T
            }
            modelClass.isAssignableFrom(StoryVM::class.java) -> {
                StoryVM(repository) as T
            }
            modelClass.isAssignableFrom(StoryAddVM::class.java) -> {
                StoryAddVM (repository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }

    companion object {
        @Volatile
        private var instance: FactoryVM? = null
        fun getInstance(context: Context): FactoryVM =
            instance ?: synchronized(this) {
                instance ?: FactoryVM(Data.provideRepository(context))
            }.also {
                instance = it
            }
    }

}