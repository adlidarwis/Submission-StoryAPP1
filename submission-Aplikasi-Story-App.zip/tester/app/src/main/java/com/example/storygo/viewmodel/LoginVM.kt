package com.example.storygo.viewmodel

import androidx.lifecycle.ViewModel
import com.example.storygo.repository.UserRepo

class LoginVM (
    private val repository: UserRepo

) : ViewModel(){
    fun login(email: String, pass: String) = repository.login(email, pass)
}